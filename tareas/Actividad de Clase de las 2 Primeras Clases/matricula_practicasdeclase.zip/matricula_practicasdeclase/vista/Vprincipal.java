package vista;

import javax.swing.*;
import java.awt.*;

/**
 * Vista: Vprincipal
 * Ventana principal MDI (Multiple Document Interface).
 * Contiene JMenuBar con submenús y un JDesktopPane como área de trabajo.
 * El Controlador accede mediante métodos públicos (Encapsulamiento).
 */
public class Vprincipal extends JFrame {

    private static final long serialVersionUID = 1L;

    // ─── Barra de menús ──────────────────────────────────────────────────────────
    private JMenuBar   menuBar;
    private JMenu      mGestionPresupuesto;
    private JMenu      mGestionObra;
    private JMenu      mReportes;
    private JMenu      msalida;

    // ── Items de menú ──
    private JMenuItem  mipresupuestacion;
    private JMenuItem  miobras;
    private JMenuItem  miconfiguracion;
    private JMenuItem  misalida;
    private JMenuItem  miinsumos;

    // ─── Área de trabajo ─────────────────────────────────────────────────────────
    private JDesktopPane escritorio;

    // ─── Constructor ─────────────────────────────────────────────────────────────
    public Vprincipal(String titulo) {
        super(titulo);
        initComponents();
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setSize(800, 600);
        this.setLocationRelativeTo(null);
        this.setExtendedState(JFrame.MAXIMIZED_BOTH);
    }

    private void initComponents() {
        // ── Menú Bar ──
        menuBar = new JMenuBar();

        // Menú Gestión de Presupuesto
        mGestionPresupuesto = new JMenu("Gestión de Presupuesto");
        mipresupuestacion   = new JMenuItem("Presupuestación");
        mGestionPresupuesto.add(mipresupuestacion);
        menuBar.add(mGestionPresupuesto);

        // Menú Gestión de Obras
        mGestionObra     = new JMenu("Gestión de Obras");
        miobras          = new JMenuItem("Obras");
        miconfiguracion  = new JMenuItem("Configuración");
        miinsumos        = new JMenuItem("Gestión de Insumos");
        mGestionObra.add(miobras);
        mGestionObra.add(miconfiguracion);
        mGestionObra.addSeparator();
        mGestionObra.add(miinsumos);
        menuBar.add(mGestionObra);

        // Menú Reportes
        mReportes = new JMenu("Reportes");
        menuBar.add(mReportes);

        // Menú Salida
        msalida  = new JMenu("Salida");
        misalida = new JMenuItem("Salir del Sistema");
        msalida.add(misalida);
        menuBar.add(msalida);

        this.setJMenuBar(menuBar);

        // ── Área de trabajo (Desktop) ──
        escritorio = new JDesktopPane();
        escritorio.setBackground(new Color(180, 195, 220));
        this.setContentPane(escritorio);
    }

    // ─── Métodos Puente ──────────────────────────────────────────────────────────
    public JMenuItem     getMipresupuestacion() { return mipresupuestacion; }
    public JMenuItem     getMiobras()           { return miobras; }
    public JMenuItem     getMiconfiguracion()   { return miconfiguracion; }
    public JMenuItem     getMisalida()          { return misalida; }
    public JMenuItem     getMiinsumos()         { return miinsumos; }
    public JDesktopPane  getEscritorio()        { return escritorio; }

    /**
     * Interruptor maestro: activa o desactiva todos los menús principales.
     * Útil para bloquear la UI mientras hay procesos en ejecución.
     * @param estado true = activar, false = bloquear
     */
    public void setEstadoMenus(boolean estado) {
        this.mGestionPresupuesto.setEnabled(estado);
        this.mGestionObra.setEnabled(estado);
        this.mReportes.setEnabled(estado);
        this.msalida.setEnabled(estado);
    }
}
