package vista;

import javax.swing.*;
import java.awt.*;

/**
 * Vista: Vejercicioclase02
 * Ventana JFrame con JComboBox y JList para gestión de listas.
 * Todos los atributos son PRIVADOS (Encapsulamiento).
 * NO contiene método main.
 */
public class Vejercicioclase02 extends JFrame {

    private static final long serialVersionUID = 1L;

    // ─── Atributos PRIVADOS ──────────────────────────────────────────────────────
    private JPanel     panelprincipal;
    private JComboBox<String>  comboBox;
    private JList<String>      listadesplegable;
    private JTextField Tdato;
    private JButton    Bagregar;
    private JButton    Beliminar;
    private JButton    Bsalir;

    // ─── Constructor ─────────────────────────────────────────────────────────────
    public Vejercicioclase02() {
        super("Ejercicio Clase 02 - Listas");
        initComponents();
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setSize(500, 400);
        this.setLocationRelativeTo(null);
        this.setResizable(false);
    }

    private void initComponents() {
        panelprincipal = new JPanel();
        panelprincipal.setLayout(null);
        panelprincipal.setBackground(new Color(240, 245, 255));

        // ── JComboBox ──
        comboBox = new JComboBox<>();
        comboBox.setBounds(20, 20, 200, 28);
        panelprincipal.add(comboBox);

        // ── Campo de texto ──
        Tdato = new JTextField();
        Tdato.setBounds(230, 20, 230, 28);
        panelprincipal.add(Tdato);

        // ── JList dentro de JScrollPane ──
        listadesplegable = new JList<>();
        JScrollPane scrollPane = new JScrollPane(listadesplegable);
        scrollPane.setBounds(20, 60, 440, 220);
        panelprincipal.add(scrollPane);

        // ── Botones ──
        Bagregar  = new JButton("Agregar");
        Bagregar.setBounds(20, 300, 120, 30);
        panelprincipal.add(Bagregar);

        Beliminar = new JButton("ELIMINAR");
        Beliminar.setBounds(160, 300, 120, 30);
        panelprincipal.add(Beliminar);

        Bsalir    = new JButton("Salida");
        Bsalir.setBounds(300, 300, 120, 30);
        panelprincipal.add(Bsalir);

        this.setContentPane(panelprincipal);
    }

    // ─── Métodos Puente ──────────────────────────────────────────────────────────
    public JList<String>     getListadesplegable() { return this.listadesplegable; }
    public JComboBox<String> getComboBox()         { return this.comboBox; }
    public JTextField        getTdato()            { return this.Tdato; }

    public JButton getBagregar()  { return this.Bagregar; }
    public JButton getBeliminar() { return this.Beliminar; }
    public JButton getBsalir()    { return this.Bsalir; }

    public void limpiarText() { this.Tdato.setText(""); }
}
