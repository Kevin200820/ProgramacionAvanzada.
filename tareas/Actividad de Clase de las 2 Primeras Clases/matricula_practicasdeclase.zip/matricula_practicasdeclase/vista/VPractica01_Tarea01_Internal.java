package vista;

import javax.swing.*;
import java.awt.*;

/**
 * Vista: VPractica01_Tarea01_Internal
 * Actividad de Evidencia 02.
 * JInternalFrame para gestión de Insumos dentro del JDesktopPane de Vprincipal.
 * Basado en VPractica01_Tarea01 pero adaptado como ventana interna.
 */
public class VPractica01_Tarea01_Internal extends JInternalFrame {

    private static final long serialVersionUID = 1L;

    // ─── Atributos PRIVADOS ──────────────────────────────────────────────────────
    private JPanel             panelFormulario;
    private JLabel             labelId;
    private JTextField         Tid;
    private JLabel             labelInsumo;
    private JTextField         Tinsumo;
    private JLabel             labelCategoria;
    private JComboBox<String>  ComoCategoria;
    private JButton            Bagregar;
    private JButton            Beliminar;
    private JButton            Bsalir;
    private JList<String>      lista;
    private JScrollPane        scrollPane;

    // ─── Constructor ─────────────────────────────────────────────────────────────
    public VPractica01_Tarea01_Internal() {
        super("Gestión de Insumos",
              true,   // resizable
              true,   // closable
              true,   // maximizable
              true);  // iconifiable
        initComponents();
        this.setSize(500, 450);
    }

    private void initComponents() {
        panelFormulario = new JPanel();
        panelFormulario.setLayout(null);
        panelFormulario.setBackground(new Color(235, 240, 250));

        labelId = new JLabel("ID:");
        labelId.setFont(new Font("SansSerif", Font.BOLD, 13));
        labelId.setBounds(15, 15, 100, 25);
        panelFormulario.add(labelId);

        Tid = new JTextField();
        Tid.setBounds(120, 15, 180, 28);
        panelFormulario.add(Tid);

        labelInsumo = new JLabel("Insumo:");
        labelInsumo.setFont(new Font("SansSerif", Font.BOLD, 13));
        labelInsumo.setBounds(15, 53, 100, 25);
        panelFormulario.add(labelInsumo);

        Tinsumo = new JTextField();
        Tinsumo.setBounds(120, 53, 340, 28);
        panelFormulario.add(Tinsumo);

        labelCategoria = new JLabel("Categoría:");
        labelCategoria.setFont(new Font("SansSerif", Font.BOLD, 13));
        labelCategoria.setBounds(15, 91, 100, 25);
        panelFormulario.add(labelCategoria);

        ComoCategoria = new JComboBox<>();
        ComoCategoria.setBounds(120, 91, 200, 28);
        panelFormulario.add(ComoCategoria);

        Bagregar = new JButton("Agregar");
        Bagregar.setBackground(new Color(70, 130, 180));
        Bagregar.setForeground(Color.WHITE);
        Bagregar.setBounds(15, 132, 120, 32);
        panelFormulario.add(Bagregar);

        Beliminar = new JButton("Eliminar");
        Beliminar.setBackground(new Color(200, 70, 70));
        Beliminar.setForeground(Color.WHITE);
        Beliminar.setBounds(148, 132, 120, 32);
        panelFormulario.add(Beliminar);

        Bsalir = new JButton("Salir");
        Bsalir.setBackground(new Color(100, 100, 100));
        Bsalir.setForeground(Color.WHITE);
        Bsalir.setBounds(282, 132, 100, 32);
        panelFormulario.add(Bsalir);

        lista = new JList<>();
        lista.setFont(new Font("Monospaced", Font.PLAIN, 12));
        lista.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        scrollPane = new JScrollPane(lista);
        scrollPane.setBounds(15, 178, 455, 225);
        panelFormulario.add(scrollPane);

        this.setContentPane(panelFormulario);
    }

    // ─── Métodos Puente ──────────────────────────────────────────────────────────
    public String getTid()     { return this.Tid.getText(); }
    public String getTinsumo() { return this.Tinsumo.getText(); }

    public JComboBox<String> getComoCategoria()   { return this.ComoCategoria; }
    public JList<String>     getLista()            { return this.lista; }
    public JButton           getBagregar()         { return this.Bagregar; }
    public JButton           getBeliminar()        { return this.Beliminar; }
    public JButton           getBsalir()           { return this.Bsalir; }

    public void limpiarText() {
        this.Tid.setText("");
        this.Tinsumo.setText("");
    }

    /**
     * Maximiza el JInternalFrame al tamaño del JDesktopPane que lo contiene.
     * Requerido por la Actividad de Evidencia 02.
     */
    public void maximizarFrame() {
        try {
            this.setMaximum(true);
        } catch (java.beans.PropertyVetoException e) {
            e.printStackTrace();
        }
    }
}
