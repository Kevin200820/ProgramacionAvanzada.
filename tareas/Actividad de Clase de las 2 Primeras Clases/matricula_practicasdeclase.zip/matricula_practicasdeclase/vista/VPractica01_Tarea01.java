package vista;

import javax.swing.*;
import java.awt.*;

/**
 * Vista: VPractica01_Tarea01
 * Actividad de Evidencia 01.
 * Ventana JFrame para un sistema CRUD de Insumos.
 * Muestra en JList: [ID] Insumo - Categoría.
 * Categorías: Materiales, Mano de Obra, Herramienta, Servicios.
 */
public class VPractica01_Tarea01 extends JFrame {

    private static final long serialVersionUID = 1L;

    // ─── Atributos PRIVADOS (Encapsulamiento / Caja Negra) ──────────────────────
    private JPanel             panelFormulario;
    private JLabel             labelId;
    private JTextField         Tid;
    private JLabel             labelInsumo;
    private JTextField         Tinsumo;
    private JLabel             labelCategoria;
    private JComboBox<String>  ComoCategoria;
    private JButton            Bagregar;
    private JButton            Beliminar;
    private JButton            Bsalir;
    private JList<String>      lista;
    private JScrollPane        scrollPane;

    // ─── Constructor ─────────────────────────────────────────────────────────────
    public VPractica01_Tarea01() {
        super("Gestión de Insumos - Práctica 01 Tarea 01");
        initComponents();
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setSize(520, 480);
        this.setLocationRelativeTo(null);
        this.setResizable(false);
    }

    private void initComponents() {
        // Panel principal con fondo suave
        panelFormulario = new JPanel();
        panelFormulario.setLayout(null);
        panelFormulario.setBackground(new Color(235, 240, 250));

        // ── Etiqueta y campo ID ──
        labelId = new JLabel("ID:");
        labelId.setFont(new Font("SansSerif", Font.BOLD, 13));
        labelId.setBounds(20, 20, 100, 25);
        panelFormulario.add(labelId);

        Tid = new JTextField();
        Tid.setBounds(130, 20, 200, 28);
        panelFormulario.add(Tid);

        // ── Etiqueta y campo Insumo ──
        labelInsumo = new JLabel("Insumo:");
        labelInsumo.setFont(new Font("SansSerif", Font.BOLD, 13));
        labelInsumo.setBounds(20, 60, 100, 25);
        panelFormulario.add(labelInsumo);

        Tinsumo = new JTextField();
        Tinsumo.setBounds(130, 60, 200, 28);
        panelFormulario.add(Tinsumo);

        // ── Etiqueta y ComboBox Categoría ──
        labelCategoria = new JLabel("Categoría:");
        labelCategoria.setFont(new Font("SansSerif", Font.BOLD, 13));
        labelCategoria.setBounds(20, 100, 100, 25);
        panelFormulario.add(labelCategoria);

        ComoCategoria = new JComboBox<>();
        ComoCategoria.setBounds(130, 100, 200, 28);
        panelFormulario.add(ComoCategoria);

        // ── Botones ──
        Bagregar = new JButton("Agregar");
        Bagregar.setBackground(new Color(70, 130, 180));
        Bagregar.setForeground(Color.WHITE);
        Bagregar.setFont(new Font("SansSerif", Font.BOLD, 12));
        Bagregar.setBounds(20, 148, 120, 32);
        panelFormulario.add(Bagregar);

        Beliminar = new JButton("Eliminar");
        Beliminar.setBackground(new Color(200, 70, 70));
        Beliminar.setForeground(Color.WHITE);
        Beliminar.setFont(new Font("SansSerif", Font.BOLD, 12));
        Beliminar.setBounds(155, 148, 120, 32);
        panelFormulario.add(Beliminar);

        Bsalir = new JButton("Salir");
        Bsalir.setBackground(new Color(100, 100, 100));
        Bsalir.setForeground(Color.WHITE);
        Bsalir.setFont(new Font("SansSerif", Font.BOLD, 12));
        Bsalir.setBounds(290, 148, 100, 32);
        panelFormulario.add(Bsalir);

        // ── JList con ScrollPane ──
        lista = new JList<>();
        lista.setFont(new Font("Monospaced", Font.PLAIN, 12));
        lista.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        scrollPane = new JScrollPane(lista);
        scrollPane.setBounds(20, 195, 460, 240);
        panelFormulario.add(scrollPane);

        this.setContentPane(panelFormulario);
    }

    // ─── Métodos Puente ──────────────────────────────────────────────────────────

    /** Extracción: ID del insumo */
    public String getTid()     { return this.Tid.getText(); }

    /** Extracción: nombre del insumo */
    public String getTinsumo() { return this.Tinsumo.getText(); }

    /** Acceso: JComboBox de categorías */
    public JComboBox<String> getComoCategoria()   { return this.ComoCategoria; }

    /** Acceso: JList de insumos */
    public JList<String>     getLista()            { return this.lista; }

    /** Acción: botón Agregar */
    public JButton getBagregar()  { return this.Bagregar; }

    /** Acción: botón Eliminar */
    public JButton getBeliminar() { return this.Beliminar; }

    /** Acción: botón Salir */
    public JButton getBsalir()    { return this.Bsalir; }

    /** Utilidad: limpia los campos de texto */
    public void limpiarText() {
        this.Tid.setText("");
        this.Tinsumo.setText("");
    }
}
