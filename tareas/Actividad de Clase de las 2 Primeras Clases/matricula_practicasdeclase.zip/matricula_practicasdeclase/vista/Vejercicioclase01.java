package vista;

import javax.swing.*;
import java.awt.*;

/**
 * Vista: Vejercicioclase01
 * Ventana JFrame con encapsulamiento (Principio Caja Negra).
 * NO contiene método main.
 * El Controlador accede a los componentes exclusivamente mediante métodos públicos.
 */
public class Vejercicioclase01 extends JFrame {

    private static final long serialVersionUID = 1L;

    // ─── Atributos PRIVADOS (Encapsulamiento) ────────────────────────────────────
    private JPanel     PanelPrincipal;
    private JTextField T1;           // Nombre Profesor
    private JTextField T2;           // Apellido
    private JButton    Bagregar;
    private JButton    Bsalir;
    private JTextArea  Tr;

    // ─── Constructor ─────────────────────────────────────────────────────────────
    public Vejercicioclase01() {
        super("Ejercicio Clase 01 - Profesores");
        initComponents();
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setSize(520, 420);
        this.setLocationRelativeTo(null);
        this.setResizable(false);
    }

    private void initComponents() {
        // Panel principal con layout nulo (coordenadas absolutas)
        PanelPrincipal = new JPanel();
        PanelPrincipal.setLayout(null);
        PanelPrincipal.setBackground(new Color(245, 245, 250));

        // ── Etiquetas ──
        JLabel lblNombre = new JLabel("Nombre Profesor:");
        lblNombre.setBounds(20, 30, 130, 25);
        PanelPrincipal.add(lblNombre);

        JLabel lblApellido = new JLabel("Apellido:");
        lblApellido.setBounds(20, 70, 130, 25);
        PanelPrincipal.add(lblApellido);

        // ── Campos de texto ──
        T1 = new JTextField();
        T1.setBounds(155, 30, 180, 25);
        PanelPrincipal.add(T1);

        T2 = new JTextField();
        T2.setBounds(155, 70, 180, 25);
        PanelPrincipal.add(T2);

        // ── Botones ──
        Bagregar = new JButton("Agregar");
        Bagregar.setBounds(350, 30, 120, 28);
        PanelPrincipal.add(Bagregar);

        Bsalir = new JButton("Salir");
        Bsalir.setBounds(350, 70, 120, 28);
        PanelPrincipal.add(Bsalir);

        // ── Área de texto con scroll ──
        Tr = new JTextArea();
        Tr.setEditable(false);
        Tr.setFont(new Font("Monospaced", Font.PLAIN, 12));
        JScrollPane scrollPane = new JScrollPane(Tr);
        scrollPane.setBounds(20, 120, 460, 240);
        PanelPrincipal.add(scrollPane);

        this.setContentPane(PanelPrincipal);
    }

    // ─── Métodos Puente (Acceso del Controlador) ─────────────────────────────────

    /** Extracción: devuelve el texto del campo Nombre */
    public String getT1() { return this.T1.getText(); }

    /** Extracción: devuelve el texto del campo Apellido */
    public String getT2() { return this.T2.getText(); }

    /** Escritura: establece el texto del campo Nombre */
    public void setT1(String texto) { this.T1.setText(texto); }

    /** Escritura: establece el texto del campo Apellido */
    public void setT2(String texto) { this.T2.setText(texto); }

    /** Escritura: envía información al área de resultados */
    public void setTr(String texto) { this.Tr.setText(texto); }

    /** Acción: devuelve el botón Salir para asignar listener */
    public JButton bsalir()    { return this.Bsalir; }

    /** Acción: devuelve el botón Agregar para asignar listener */
    public JButton bagregar()  { return this.Bagregar; }

    /** Utilidad: limpia los campos de texto de la vista */
    public void limparText() {
        this.T1.setText("");
        this.T2.setText("");
    }
}
