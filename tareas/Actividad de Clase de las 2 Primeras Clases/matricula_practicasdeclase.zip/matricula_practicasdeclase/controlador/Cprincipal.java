package controlador;

import libreria.DesktopManager;
import modelo.ModeloInsumo;
import vista.Vprincipal;
import vista.VPractica01_Tarea01_Internal;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;

/**
 * Controlador: Cprincipal
 * Actividad de Evidencia 02.
 * Gestiona la ventana principal MDI (Vprincipal).
 * Abre JInternalFrame de Insumos y Obras dentro del JDesktopPane.
 */
public class Cprincipal implements ActionListener {

    Vprincipal ventana;

    public Cprincipal() {
        ventana = new Vprincipal("Sistema de Presupuesto");
        ventana.setVisible(true);

        // Registrar todos los items de menú con this
        this.ventana.getMiconfiguracion().addActionListener(this);
        this.ventana.getMiobras().addActionListener(this);
        this.ventana.getMisalida().addActionListener(this);
        this.ventana.getMipresupuestacion().addActionListener(this);
        this.ventana.getMiinsumos().addActionListener(this);
    }

    /**
     * Semáforo central de eventos.
     * Bloquea menús al entrar, los reactiva al salir.
     */
    @Override
    public void actionPerformed(ActionEvent e) {
        // Bloqueo preventivo
        this.ventana.setEstadoMenus(false);

        // ── Presupuestación ────────────────────────────────────────────────────
        if (e.getSource() == this.ventana.getMipresupuestacion()) {
            JOptionPane.showMessageDialog(
                this.ventana.getEscritorio(),
                "Abriendo Módulo de Presupuestación..."
            );
        }

        // ── Obras ──────────────────────────────────────────────────────────────
        else if (e.getSource() == this.ventana.getMiobras()) {
            JOptionPane.showMessageDialog(
                this.ventana.getEscritorio(),
                "Abriendo Gestión de Obras..."
            );
        }

        // ── Configuración ──────────────────────────────────────────────────────
        else if (e.getSource() == this.ventana.getMiconfiguracion()) {
            JOptionPane.showMessageDialog(
                this.ventana.getEscritorio(),
                "Accediendo a la Configuración del Sistema..."
            );
        }

        // ── Gestión de Insumos (JInternalFrame) ───────────────────────────────
        else if (e.getSource() == this.ventana.getMiinsumos()) {
            abrirInsumos();
        }

        // ── Salir ──────────────────────────────────────────────────────────────
        else if (e.getSource() == this.ventana.getMisalida()) {
            int opcion = JOptionPane.showConfirmDialog(
                this.ventana.getEscritorio(),
                "¿Seguro que desea salir?",
                "Salir",
                JOptionPane.YES_NO_OPTION
            );
            if (opcion == 0) {
                this.ventana.dispose();
                System.exit(0);
            }
        }

        // Reactivación de menús
        this.ventana.setEstadoMenus(true);
    }

    /**
     * Abre el módulo de Gestión de Insumos como JInternalFrame.
     * Usa DesktopManager para no duplicar ventanas y centrarlas.
     */
    private void abrirInsumos() {
        VPractica01_Tarea01_Internal frameInsumos = new VPractica01_Tarea01_Internal();
        ModeloInsumo modelo = new ModeloInsumo();

        // Vincular modelos
        frameInsumos.getComoCategoria().setModel(modelo.getModeloCategoria());
        frameInsumos.getLista().setModel(modelo.getModeloLista());

        // Eventos del JInternalFrame
        frameInsumos.getBagregar().addActionListener(ev -> {
            String id       = frameInsumos.getTid().trim();
            String nombre   = frameInsumos.getTinsumo().trim();
            String categoria = (String) frameInsumos.getComoCategoria().getSelectedItem();

            if (id.isEmpty() || nombre.isEmpty()) {
                JOptionPane.showMessageDialog(frameInsumos,
                    "ID e Insumo son obligatorios.", "Aviso",
                    JOptionPane.WARNING_MESSAGE);
                return;
            }
            if (modelo.agregar(id, nombre, categoria)) {
                frameInsumos.limpiarText();
                JOptionPane.showMessageDialog(frameInsumos, "Insumo agregado.");
            } else {
                JOptionPane.showMessageDialog(frameInsumos,
                    "El ID ya existe.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        frameInsumos.getBeliminar().addActionListener(ev -> {
            int sel = frameInsumos.getLista().getSelectedIndex();
            if (sel < 0) {
                JOptionPane.showMessageDialog(frameInsumos,
                    "Selecciona un elemento.", "Aviso",
                    JOptionPane.WARNING_MESSAGE);
                return;
            }
            String eliminado = modelo.eliminar(sel);
            JOptionPane.showMessageDialog(frameInsumos, "Eliminado: " + eliminado);
        });

        frameInsumos.getBsalir().addActionListener(ev -> {
            frameInsumos.dispose();
        });

        // Abrir usando librería (evita duplicados y centra)
        DesktopManager.abrirUnico(this.ventana.getEscritorio(), frameInsumos);
    }
}
