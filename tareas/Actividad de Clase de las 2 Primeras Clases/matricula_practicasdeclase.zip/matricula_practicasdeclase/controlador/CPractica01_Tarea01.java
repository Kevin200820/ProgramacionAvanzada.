package controlador;

import modelo.ModeloInsumo;
import vista.VPractica01_Tarea01;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;

/**
 * Controlador: CPractica01_Tarea01
 * Actividad de Evidencia 01.
 * Gestiona el CRUD de Insumos entre VPractica01_Tarea01 y ModeloInsumo.
 */
public class CPractica01_Tarea01 implements ActionListener {

    VPractica01_Tarea01 vista;
    ModeloInsumo        modelo;

    public CPractica01_Tarea01() {
        vista  = new VPractica01_Tarea01();
        modelo = new ModeloInsumo();

        // Vincular modelo de categorías al ComboBox de la vista
        vista.getComoCategoria().setModel(modelo.getModeloCategoria());

        // Vincular modelo de lista al JList de la vista
        vista.getLista().setModel(modelo.getModeloLista());

        // Registrar listeners
        vista.getBagregar().addActionListener(this);
        vista.getBeliminar().addActionListener(this);
        vista.getBsalir().addActionListener(this);

        vista.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        // ── Botón Agregar ──────────────────────────────────────────────────────
        if (e.getSource() == vista.getBagregar()) {
            // 1. Normalización (trim elimina espacios accidentales)
            String id       = vista.getTid().trim();
            String nombre   = vista.getTinsumo().trim();
            String categoria = (String) vista.getComoCategoria().getSelectedItem();

            // 2. Validación
            if (id.isEmpty() || nombre.isEmpty()) {
                JOptionPane.showMessageDialog(
                    null,
                    "ID e Insumo son campos obligatorios.",
                    "Campos Vacíos",
                    JOptionPane.WARNING_MESSAGE
                );
                return;
            }

            // 3. Inserción
            boolean exito = modelo.agregar(id, nombre, categoria);
            if (!exito) {
                JOptionPane.showMessageDialog(
                    null,
                    "Ya existe un insumo con el ID: " + id,
                    "ID Duplicado",
                    JOptionPane.ERROR_MESSAGE
                );
                return;
            }

            // 4. Refresco
            vista.limpiarText();
            JOptionPane.showMessageDialog(null, "Insumo agregado correctamente.");
        }

        // ── Botón Eliminar ─────────────────────────────────────────────────────
        else if (e.getSource() == vista.getBeliminar()) {
            int seleccion = vista.getLista().getSelectedIndex();

            if (seleccion < 0) {
                JOptionPane.showMessageDialog(
                    null,
                    "Selecciona un insumo de la lista para eliminarlo.",
                    "Sin selección",
                    JOptionPane.WARNING_MESSAGE
                );
                return;
            }

            String eliminado = modelo.eliminar(seleccion);
            JOptionPane.showMessageDialog(null, "Eliminado: " + eliminado);
        }

        // ── Botón Salir ────────────────────────────────────────────────────────
        else if (e.getSource() == vista.getBsalir()) {
            int opcion = JOptionPane.showConfirmDialog(
                null,
                "¿Desea salir del programa?",
                "Salir",
                JOptionPane.YES_NO_OPTION
            );
            if (opcion == 0)
                vista.dispose();
            else
                JOptionPane.showMessageDialog(null, "¡Gracias por continuar!");
        }
    }
}
