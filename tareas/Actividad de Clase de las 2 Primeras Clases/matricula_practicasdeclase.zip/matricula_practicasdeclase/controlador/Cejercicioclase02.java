package controlador;

import modelo.Mejercicio02;
import vista.Vejercicioclase02;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;

/**
 * Controlador: Cejercicioclase02
 * Gestiona la interacción entre Vejercicioclase02 y Mejercicio02.
 * Implementa ActionListener para centralizar todos los eventos.
 */
public class Cejercicioclase02 implements ActionListener {

    Vejercicioclase02 vista;
    Mejercicio02      modelo;

    public Cejercicioclase02() {
        vista  = new Vejercicioclase02();
        modelo = new Mejercicio02();

        // Vincular modelos a la vista (casamiento)
        this.vista.getComboBox().setModel(modelo.getListacombo());
        this.vista.getListadesplegable().setModel(modelo.getLista());

        // Registrar eventos
        this.vista.getBagregar().addActionListener(this);
        this.vista.getBsalir().addActionListener(this);
        this.vista.getBeliminar().addActionListener(this);

        this.vista.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        // ── Botón Agregar ──────────────────────────────────────────────────────
        if (e.getSource() == vista.getBagregar()) {
            String dato = vista.getTdato().getText().trim();
            if (!dato.isEmpty()) {
                modelo.AgregarCombo(dato);
                modelo.AgregarLista(dato);
                vista.limpiarText();
            }
        }

        // ── Botón Eliminar ─────────────────────────────────────────────────────
        else if (e.getSource() == vista.getBeliminar()) {
            int s1 = vista.getComboBox().getSelectedIndex();
            int s2 = vista.getListadesplegable().getSelectedIndex();

            if ((s1 < 0) && (s2 < 0)) {
                JOptionPane.showMessageDialog(null, "¡Selecciona un elemento para eliminar!");
            } else {
                if (s1 >= 0) modelo.EliminarCombo(s1);
                if (s2 >= 0) modelo.EliminarLista(s2);
            }
        }

        // ── Botón Salir ────────────────────────────────────────────────────────
        else if (e.getSource() == vista.getBsalir()) {
            int opcion = JOptionPane.showConfirmDialog(
                null,
                "¿Desea salir del programa?",
                "Salir",
                JOptionPane.YES_NO_OPTION
            );
            if (opcion == 0)
                vista.dispose();
            else
                JOptionPane.showMessageDialog(null, "¡Gracias por continuar con nosotros!");
        }
    }
}
