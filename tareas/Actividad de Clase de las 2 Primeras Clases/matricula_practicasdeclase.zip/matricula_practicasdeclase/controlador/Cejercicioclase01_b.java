package controlador;

import modelo.Cpersona;
import modelo.Lista;
import vista.Vejercicioclase01;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;

/**
 * Controlador: Cejercicioclase01_b
 * Versión B: la clase misma implementa ActionListener (patrón Interface).
 * Centraliza todos los eventos en un único método actionPerformed.
 */
public class Cejercicioclase01_b implements ActionListener {

    static Vejercicioclase01 ejemplo01;
    static Lista              lista;

    public Cejercicioclase01_b() {
        lista     = new Lista();
        ejemplo01 = new Vejercicioclase01();
        ejemplo01.setVisible(true);

        // Registrar this como oyente de ambos botones
        ejemplo01.bsalir().addActionListener(this);
        ejemplo01.bagregar().addActionListener(this);
    }

    /**
     * Semáforo central: determina qué botón disparó el evento.
     */
    @Override
    public void actionPerformed(ActionEvent e) {

        // ── Botón Salir ────────────────────────────────────────────────────────
        if (e.getSource() == ejemplo01.bsalir()) {
            int opcion = JOptionPane.showConfirmDialog(
                null,
                "¿Desea salir del programa?",
                "Salir",
                JOptionPane.YES_NO_OPTION
            );
            if (opcion == 0)
                ejemplo01.dispose();
            else
                JOptionPane.showMessageDialog(null, "¡Gracias por continuar con nosotros!");
        }

        // ── Botón Agregar ──────────────────────────────────────────────────────
        else if (e.getSource() == ejemplo01.bagregar()) {
            // 1. Normalización
            String nombre   = ejemplo01.getT1().trim();
            String apellido = ejemplo01.getT2().trim();

            // 2. Validación
            if (nombre.isEmpty() || apellido.isEmpty()) {
                JOptionPane.showMessageDialog(
                    null,
                    "Error: Todos los campos son obligatorios",
                    "Campos Vacíos",
                    JOptionPane.WARNING_MESSAGE
                );
                return;
            }

            // 3. Transformación y persistencia
            Cpersona nodo = new Cpersona(nombre, apellido);
            lista.insertar(nodo);

            // 4. Refresco de vista
            ejemplo01.limparText();
            ejemplo01.setTr(lista.info() + "\n.............\n");

            // 5. Confirmación
            JOptionPane.showMessageDialog(null, "Persona agregada correctamente");
        }
    }
}
