package controlador;

import modelo.Cpersona;
import modelo.Lista;
import vista.Vejercicioclase01;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Controlador: Cejercicioclase01
 * Versión A: usa clases anónimas para ActionListener.
 * Intermediario entre Vejercicioclase01 y Lista.
 */
public class Cejercicioclase01 {

    static Vejercicioclase01 ejemplo01;
    static Lista              lista;

    public Cejercicioclase01() {
        lista     = new Lista();
        ejemplo01 = new Vejercicioclase01();
        ejemplo01.setVisible(true);

        // ── Evento Botón Salir ─────────────────────────────────────────────────
        ejemplo01.bsalir().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ejemplo01.dispose();
            }
        });

        // ── Evento Botón Agregar ───────────────────────────────────────────────
        ejemplo01.bagregar().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String nombre   = ejemplo01.getT1().trim();
                String apellido = ejemplo01.getT2().trim();

                if (nombre.isEmpty() || apellido.isEmpty()) {
                    javax.swing.JOptionPane.showMessageDialog(
                        null,
                        "Error: Todos los campos son obligatorios",
                        "Campos Vacíos",
                        javax.swing.JOptionPane.WARNING_MESSAGE
                    );
                    return;
                }

                Cpersona nodo = new Cpersona(nombre, apellido);
                lista.insertar(nodo);
                ejemplo01.limparText();
                ejemplo01.setTr(lista.info() + "\n.............\n");
            }
        });
    }
}
