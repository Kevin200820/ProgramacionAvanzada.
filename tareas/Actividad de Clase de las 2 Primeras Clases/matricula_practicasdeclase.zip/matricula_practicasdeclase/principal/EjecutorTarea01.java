package principal;

import controlador.CPractica01_Tarea01;

/**
 * Ejecutor para la Actividad de Evidencia 01 (CRUD de Insumos con JList).
 */
public class EjecutorTarea01 {
    static CPractica01_Tarea01 controlador;

    public static void main(String[] args) {
        try {
            controlador = new CPractica01_Tarea01();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
