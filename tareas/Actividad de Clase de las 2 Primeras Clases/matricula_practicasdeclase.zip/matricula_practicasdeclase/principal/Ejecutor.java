package principal;

import controlador.Cejercicioclase01_b;

/**
 * Clase: Ejecutor
 * Punto de arranque del sistema (Launcher).
 * La JVM busca este método main para iniciar la ejecución.
 * Su única responsabilidad: dar vida al Controlador.
 *
 * Para ejecutar el Ejercicio de Clase 01 (con Controlador implementando ActionListener).
 * Cambia la clase instanciada para probar los demás controladores.
 */
public class Ejecutor {

    static Cejercicioclase01_b controlador;

    public static void main(String[] args) {
        try {
            controlador = new Cejercicioclase01_b();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
