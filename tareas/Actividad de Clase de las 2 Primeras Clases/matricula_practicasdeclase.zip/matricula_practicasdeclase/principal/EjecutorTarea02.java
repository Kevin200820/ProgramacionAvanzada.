package principal;

import controlador.Cprincipal;

/**
 * Ejecutor para la Actividad de Evidencia 02 (Ventana MDI con JDesktopPane).
 * Lanza el controlador principal que gestiona menús y JInternalFrames.
 */
public class EjecutorTarea02 {
    static Cprincipal controlador;

    public static void main(String[] args) {
        try {
            controlador = new Cprincipal();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
