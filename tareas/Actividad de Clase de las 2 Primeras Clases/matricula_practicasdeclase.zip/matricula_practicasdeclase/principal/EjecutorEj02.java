package principal;

import controlador.Cejercicioclase02;

/**
 * Ejecutor para el Ejercicio de Clase 02 (JComboBox + JList).
 */
public class EjecutorEj02 {
    static Cejercicioclase02 controlador;

    public static void main(String[] args) {
        try {
            controlador = new Cejercicioclase02();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
