package modelo;

/**
 * Clase Modelo: Insumo
 * Representa un insumo de construcción con ID, nombre e categoría.
 * Categorías posibles: Materiales, Mano de Obra, Herramienta, Servicios.
 */
public class Insumo {
    private String id;
    private String insumo;
    private String categoria;

    /**
     * Constructor principal.
     * @param id        Código único del insumo
     * @param insumo    Nombre o descripción del insumo
     * @param categoria Categoría del insumo
     */
    public Insumo(String id, String insumo, String categoria) {
        this.id        = id;
        this.insumo    = insumo;
        this.categoria = categoria;
    }

    // ─── Getters ────────────────────────────────────────────────────────────────
    public String getId()        { return id; }
    public String getInsumo()    { return insumo; }
    public String getCategoria() { return categoria; }

    // ─── Setters ────────────────────────────────────────────────────────────────
    public void setId(String id)               { this.id = id; }
    public void setInsumo(String insumo)       { this.insumo = insumo; }
    public void setCategoria(String categoria) { this.categoria = categoria; }

    /**
     * Formato para mostrar en JList:  [ID] NombreInsumo - Categoria
     */
    @Override
    public String toString() {
        return "[" + id + "] " + insumo + " - " + categoria;
    }
}
