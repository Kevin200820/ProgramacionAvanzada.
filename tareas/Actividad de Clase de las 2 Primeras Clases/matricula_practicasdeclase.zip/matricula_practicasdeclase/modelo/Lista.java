package modelo;

import java.util.ArrayList;
import java.util.List;

/**
 * Clase Modelo: Lista
 * Estructura de datos que almacena objetos Cpersona.
 * Proporciona métodos de inserción y recuperación de información.
 */
public class Lista {
    private List<Cpersona> lista;

    public Lista() {
        this.lista = new ArrayList<Cpersona>();
    }

    /**
     * Inserta una persona al final de la lista.
     * @param nodo Objeto Cpersona a insertar
     */
    public void insertar(Cpersona nodo) {
        this.lista.add(nodo);
    }

    /**
     * Retorna un String con la información de todos los elementos.
     * Utiliza el toString() de Cpersona para el formato.
     */
    public String info() {
        String dato = "";
        for (Cpersona nodo : this.lista)
            dato = dato + nodo.toString();
        return dato;
    }

    /**
     * Retorna el tamaño actual de la lista.
     */
    public int size() {
        return this.lista.size();
    }
}
