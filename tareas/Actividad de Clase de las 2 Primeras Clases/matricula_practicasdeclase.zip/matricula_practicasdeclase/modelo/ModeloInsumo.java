package modelo;

import javax.swing.DefaultComboBoxModel;
import javax.swing.DefaultListModel;

/**
 * Clase Modelo: ModeloInsumo
 * Gestiona los modelos de datos (DefaultComboBoxModel y DefaultListModel)
 * para la Vista VPractica01_Tarea01.
 * Contiene la lógica de agregar y eliminar insumos de ambas estructuras.
 */
public class ModeloInsumo {

    private DefaultComboBoxModel<String> modeloCategoria;
    private DefaultListModel<String>     modeloLista;
    private ListaInsumo                  listaInsumos;

    /** Categorías predefinidas del sistema */
    private static final String[] CATEGORIAS = {
        "Materiales", "Mano de Obra", "Herramienta", "Servicios"
    };

    public ModeloInsumo() {
        this.modeloCategoria = new DefaultComboBoxModel<>();
        this.modeloLista     = new DefaultListModel<>();
        this.listaInsumos    = new ListaInsumo();
        this.inicializarCategorias();
    }

    // ─── Inicialización ──────────────────────────────────────────────────────────
    private void inicializarCategorias() {
        for (String cat : CATEGORIAS)
            modeloCategoria.addElement(cat);
    }

    // ─── Getters ─────────────────────────────────────────────────────────────────
    public DefaultComboBoxModel<String> getModeloCategoria() { return modeloCategoria; }
    public DefaultListModel<String>     getModeloLista()     { return modeloLista; }
    public static String[]              getCategorias()      { return CATEGORIAS; }

    // ─── Operaciones CRUD ─────────────────────────────────────────────────────────

    /**
     * Agrega un insumo a la lista interna y actualiza el DefaultListModel.
     * @param id        Código único del insumo
     * @param nombre    Nombre del insumo
     * @param categoria Categoría seleccionada
     * @return true si se insertó, false si el ID ya existe
     */
    public boolean agregar(String id, String nombre, String categoria) {
        if (listaInsumos.existe(id)) return false;
        Insumo ins = new Insumo(id, nombre, categoria);
        listaInsumos.insertar(ins);
        modeloLista.addElement(ins.toString());
        return true;
    }

    /**
     * Elimina el insumo en la posición indicada del JList y de la lista interna.
     * @param pos Índice seleccionado en el JList
     * @return String del elemento eliminado
     */
    public String eliminar(int pos) {
        if (pos < 0 || pos >= listaInsumos.size()) return null;
        Insumo eliminado = listaInsumos.eliminar(pos);
        modeloLista.remove(pos);
        return eliminado.toString();
    }

    public int size() { return listaInsumos.size(); }
}
