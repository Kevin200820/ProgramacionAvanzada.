package modelo;

import java.util.Objects;

/**
 * Clase Modelo: Cpersona
 * Representa a una persona (alumno/profesor) con nombre, apellido e ID.
 * Implementa toString(), equals() y hashCode() como buenas prácticas de POO.
 */
public class Cpersona {
    private String id;
    private String nombre;
    private String apellido;

    /**
     * Constructor principal.
     * @param nombre  Nombre de la persona
     * @param apellido Apellido de la persona
     */
    public Cpersona(String nombre, String apellido) {
        super();
        this.setNombre(nombre);
        this.setApellido(apellido);
    }

    // ─── Getters ────────────────────────────────────────────────────────────────
    public String getId()       { return id; }
    public String getNombre()   { return nombre; }
    public String getApellido() { return apellido; }

    // ─── Setters ────────────────────────────────────────────────────────────────
    public void setId(String id)           { this.id = id; }
    public void setApellido(String apellido) { this.apellido = apellido; }
    public void setNombre(String nombre)   { this.nombre = nombre; }

    /**
     * Representación legible del objeto para mostrar en JTextArea.
     */
    @Override
    public String toString() {
        return this.getNombre() + " " + this.getApellido() + "\n";
    }

    /**
     * Compara dos Cpersona por su ID (no por referencia de memoria).
     */
    @Override
    public boolean equals(Object obj) {
        if (!(obj instanceof Cpersona))
            return false;
        else {
            Cpersona otro = (Cpersona) obj;
            if (this.getId().compareTo(otro.getId()) == 0)
                return true;
            else
                return false;
        }
    }

    /**
     * Contrato de Java: si equals() es true, hashCode() debe ser igual.
     */
    @Override
    public int hashCode() {
        return Objects.hash(id);
    }
}
