package modelo;

import javax.swing.DefaultComboBoxModel;
import javax.swing.DefaultListModel;

/**
 * Clase Modelo: Mejercicio02
 * Gestiona los modelos de datos para JComboBox y JList en la Vista de Ejercicio 02.
 * Contiene lógica de negocio para agregar y eliminar elementos.
 */
public class Mejercicio02 {

    private DefaultComboBoxModel<String> listacombo;
    private DefaultListModel<String>     lista;
    private String[] equipos = {"America", "Patriots", "Real Madrid", "Celtics de Boston", "Yankees"};

    public Mejercicio02() {
        this.listacombo = new DefaultComboBoxModel<>();
        this.lista      = new DefaultListModel<>();
        this.inicializarcombo();
        this.inicializarlistmodel();
    }

    // ─── Inicialización ──────────────────────────────────────────────────────────
    private void inicializarcombo() {
        for (String dato : this.equipos)
            listacombo.addElement(dato);
    }

    private void inicializarlistmodel() {
        for (String dato : this.equipos)
            lista.addElement(dato);
    }

    // ─── Getters ─────────────────────────────────────────────────────────────────
    public DefaultComboBoxModel<String> getListacombo() { return listacombo; }
    public DefaultListModel<String>     getLista()       { return lista; }
    public String[]                     getEquipos()     { return equipos; }

    // ─── Operaciones ──────────────────────────────────────────────────────────────
    public void AgregarCombo(String info) { listacombo.addElement(info); }
    public void AgregarLista(String info) { lista.addElement(info); }

    public String EliminarCombo(int pos1) {
        String c1 = listacombo.getElementAt(pos1);
        listacombo.removeElementAt(pos1);
        return c1;
    }

    public String EliminarLista(int pos1) {
        String c1 = lista.getElementAt(pos1);
        lista.remove(pos1);
        return c1;
    }
}
