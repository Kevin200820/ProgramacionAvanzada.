package modelo;

import java.util.ArrayList;
import java.util.List;

/**
 * Clase Modelo: ListaInsumo
 * Estructura de datos que almacena y gestiona objetos Insumo.
 */
public class ListaInsumo {
    private List<Insumo> lista;

    public ListaInsumo() {
        this.lista = new ArrayList<Insumo>();
    }

    /**
     * Agrega un insumo al final de la lista.
     */
    public void insertar(Insumo nodo) {
        this.lista.add(nodo);
    }

    /**
     * Elimina el insumo en la posición indicada.
     * @param pos Índice del elemento a eliminar
     * @return El insumo eliminado
     */
    public Insumo eliminar(int pos) {
        return this.lista.remove(pos);
    }

    /**
     * Busca si ya existe un insumo con ese ID.
     */
    public boolean existe(String id) {
        for (Insumo ins : this.lista) {
            if (ins.getId().equalsIgnoreCase(id.trim()))
                return true;
        }
        return false;
    }

    public int size() { return this.lista.size(); }

    public Insumo get(int pos) { return this.lista.get(pos); }
}
