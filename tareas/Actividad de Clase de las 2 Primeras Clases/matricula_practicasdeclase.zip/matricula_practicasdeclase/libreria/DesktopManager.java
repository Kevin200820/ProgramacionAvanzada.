package libreria;

import javax.swing.JDesktopPane;
import javax.swing.JInternalFrame;

/**
 * Librería: DesktopManager
 * Clase utilitaria para gestionar JInternalFrame dentro de un JDesktopPane.
 *
 * Proporciona:
 *  - centrarFrame(): centra un JInternalFrame en el JDesktopPane
 *  - abrirUnico(): abre una sola instancia de cada tipo de ventana interna
 *
 * Actividad de Evidencia 02.
 */
public class DesktopManager {

    /**
     * Centra un JInternalFrame dentro del JDesktopPane que lo contiene.
     * Debe llamarse DESPUÉS de agregar el frame al desktop.
     *
     * @param desktop JDesktopPane contenedor
     * @param frame   JInternalFrame a centrar
     */
    public static void centrarFrame(JDesktopPane desktop, JInternalFrame frame) {
        if (desktop == null || frame == null) return;

        int desktopWidth  = desktop.getWidth();
        int desktopHeight = desktop.getHeight();
        int frameWidth    = frame.getWidth();
        int frameHeight   = frame.getHeight();

        int x = (desktopWidth  - frameWidth)  / 2;
        int y = (desktopHeight - frameHeight) / 2;

        // Evitar coordenadas negativas
        if (x < 0) x = 0;
        if (y < 0) y = 0;

        frame.setLocation(x, y);
    }

    /**
     * Abre una única instancia de un JInternalFrame.
     * Si el frame ya está abierto, lo trae al frente sin crear uno nuevo.
     *
     * @param desktop JDesktopPane contenedor
     * @param frame   JInternalFrame que se desea mostrar
     */
    public static void abrirUnico(JDesktopPane desktop, JInternalFrame frame) {
        if (desktop == null || frame == null) return;

        // Revisar si ya existe en el desktop
        for (JInternalFrame f : desktop.getAllFrames()) {
            if (f.getClass().equals(frame.getClass())) {
                try {
                    f.setIcon(false);    // Restaurar si estaba minimizado
                    f.setSelected(true); // Traer al frente
                } catch (java.beans.PropertyVetoException e) {
                    e.printStackTrace();
                }
                return; // Ya existe, no abrir otra
            }
        }

        // Si no existe, agregarlo y centrarlo
        desktop.add(frame);
        centrarFrame(desktop, frame);
        frame.setVisible(true);

        try {
            frame.setSelected(true);
        } catch (java.beans.PropertyVetoException e) {
            e.printStackTrace();
        }
    }

    /**
     * Cierra y elimina todos los JInternalFrame del desktop.
     * @param desktop JDesktopPane a limpiar
     */
    public static void cerrarTodos(JDesktopPane desktop) {
        for (JInternalFrame f : desktop.getAllFrames()) {
            f.dispose();
        }
    }
}
